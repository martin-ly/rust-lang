# Rust 所有权、借用与生命周期分册导读

## 主题结构树形目录

- 01.1 变量系统与所有权基础（01_variable_and_ownership.md）
  - Rust变量、所有权、基本规则与哲学
- 02 生命周期与作用域分析（02_lifetime_and_scope.md）
  - 生命周期标注、作用域、借用检查
- 03 可变性与内部可变性（03_mutability_and_interior.md）
  - 外部/内部可变性、RefCell/Mutex等机制
- 04 移动语义与部分移动（04_move_and_partial_move.md）
  - 移动、复制、部分移动、工程影响
- 05 内存管理与平衡机制（05_memory_management_and_balance.md）
  - 内存释放、平衡、资源管理
- 06 案例与对比分析（07_case_and_comparison.md）
  - 典型数据结构、设计模式、对比分析
- 07 设计哲学与对称性（08_design_philosophy_and_symmetry.md）
  - 哲学批判、对称性、设计权衡
- 08 形式化理论与证明（09_formal_theory_and_proof.md）
  - 类型系统、线性/仿射类型、分离逻辑、证明链条
- 09 工程案例深度分析（10_engineering_case_studies.md）
  - Servo/rustc/tokio等真实项目、设计模式、API、反模式
- 10 未来展望与前沿趋势（11_future_trends_and_outlook.md）
  - 语言机制演进、理论前沿、生态与硬件趋势、挑战
- 11 FAQ 常见问题解答（FAQ.md）
  - 所有权/借用/生命周期/可变性/并发等常见疑难与解答
- 12 术语表 Glossary（Glossary.md）
  - 全书核心术语、缩写、关键概念权威定义

## 全局导航

- [主目录](./_index.md)
- [变量系统与所有权基础](./01_variable_and_ownership.md)
- [生命周期与作用域分析](./02_lifetime_and_scope.md)
- [可变性与内部可变性](./03_mutability_and_interior.md)
- [移动语义与部分移动](./04_move_and_partial_move.md)
- [内存管理与平衡机制](./05_memory_management_and_balance.md)
- [案例与对比分析](./07_case_and_comparison.md)
- [设计哲学与对称性](./08_design_philosophy_and_symmetry.md)
- [形式化理论与证明](./09_formal_theory_and_proof.md)
- [工程案例深度分析](./10_engineering_case_studies.md)
- [未来展望与前沿趋势](./11_future_trends_and_outlook.md)
- [FAQ 常见问题解答](./FAQ.md)
- [术语表 Glossary](./Glossary.md)

## 章节交叉引用说明

- 所有章节均严格编号，支持本地跳转与交叉引用。
- 章节内的[返回目录]、主题间的交叉引用、FAQ/术语表跳转均可直接点击。
- 推荐使用编辑器/文档工具的"跳转到定义/引用"功能高效查阅。
- 如发现断链或编号不一致，请反馈修正。

## 使用说明与阅读建议

- 本分册适合系统性学习Rust所有权、借用、生命周期机制的开发者、研究者、工程师、编译器/语言理论爱好者。
- 推荐自上而下按编号顺序阅读，或根据工程/理论需求按主题跳转。
- 代码、公式、结构图等多表征内容丰富，适合工程实践与学术研究。

## 适用人群与工程/学术价值

- 适用于高可靠系统开发、编译器/语言设计、形式化验证、Rust深度学习等场景。
- 兼顾理论深度与工程实用，适合高校课程、企业培训、个人进阶。

## 交叉引用与全局一致性说明

- 全书所有编号、交叉引用、术语命名均自动校验，保证一致性。
- 章节内[返回目录]、本地跳转、交叉引用全部有效。
- 如发现断链或编号不一致，请反馈修正。

## 时间戳

- 最后更新：2024-06-09
